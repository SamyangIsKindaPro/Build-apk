package com.example

import com.example.data.local.UserPreferences
import com.example.data.model.ActivityType
import com.example.data.model.BroadcastMode
import com.example.data.model.RichPresencePayload
import com.example.ui.components.formatDuration
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun activityType_resolvesAllCodesAndFallback() {
        assertEquals(ActivityType.PLAYING, ActivityType.fromCode(0))
        assertEquals(ActivityType.STREAMING, ActivityType.fromCode(1))
        assertEquals(ActivityType.LISTENING, ActivityType.fromCode(2))
        assertEquals(ActivityType.WATCHING, ActivityType.fromCode(3))
        assertEquals(ActivityType.COMPETING, ActivityType.fromCode(5))
        assertEquals(ActivityType.PLAYING, ActivityType.fromCode(999))
    }

    @Test
    fun formatDuration_formatsMinutesAndHours() {
        assertEquals("00:45", formatDuration(45))
        assertEquals("05:09", formatDuration(309))
        assertEquals("01:02:03", formatDuration(3723))
    }

    @Test
    fun richPresencePayload_hasExpectedDefaults() {
        val payload = RichPresencePayload(name = "Mobile Legends")
        assertEquals(RichPresencePayload.DEFAULT_DISCORD_APP_ID, payload.applicationId)
        assertEquals(ActivityType.PLAYING, payload.activityType)
        assertEquals(3, BroadcastMode.entries.size)
    }

    @Test
    fun userPreferences_computesCustomElapsedOffsetMs() {
        val prefs = UserPreferences(
            customElapsedEnabled = true,
            customElapsedMinutes = 36,
            customElapsedSeconds = 15
        )
        assertEquals(2_175_000L, prefs.customElapsedOffsetMs)
    }
}
