package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PulseRpcDao {
    // App Rules
    @Query("SELECT * FROM app_rules ORDER BY appName ASC")
    fun observeAllAppRules(): Flow<List<AppRuleEntity>>

    @Query("SELECT * FROM app_rules WHERE packageName = :packageName LIMIT 1")
    suspend fun getAppRule(packageName: String): AppRuleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAppRule(rule: AppRuleEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMissingAppRules(rules: List<AppRuleEntity>)

    // Presets
    @Query("SELECT * FROM presence_presets ORDER BY createdAtMs DESC")
    fun observePresets(): Flow<List<PresencePresetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPreset(preset: PresencePresetEntity): Long

    @Query("DELETE FROM presence_presets WHERE id = :id")
    suspend fun deletePresetById(id: Long)

    // Activity Logs
    @Query("SELECT * FROM activity_logs ORDER BY timestampMs DESC LIMIT 40")
    fun observeRecentLogs(): Flow<List<ActivityLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ActivityLogEntity)

    @Query("DELETE FROM activity_logs")
    suspend fun clearLogs()
}
