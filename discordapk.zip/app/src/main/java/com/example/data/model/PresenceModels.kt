package com.example.data.model

import android.graphics.drawable.Drawable

enum class BroadcastMode(val label: String, val description: String) {
    AUTO_APP("Auto App", "Detects the active app or game on screen"),
    MEDIA("Now Playing", "Reads active music & video player notifications"),
    CUSTOM("Custom RPC", "Broadcasts your handcrafted presence")
}

enum class ActivityType(val code: Int, val prefixLabel: String, val badgeTitle: String) {
    PLAYING(0, "Playing", "PLAYING A GAME"),
    STREAMING(1, "Streaming", "LIVE ON STREAM"),
    LISTENING(2, "Listening to", "LISTENING TO"),
    WATCHING(3, "Watching", "WATCHING"),
    COMPETING(5, "Competing in", "COMPETING IN");

    companion object {
        fun fromCode(code: Int): ActivityType = entries.firstOrNull { it.code == code } ?: PLAYING
    }
}

enum class GatewayStatus(val label: String) {
    DISCONNECTED("Offline"),
    CONNECTING("Connecting..."),
    CONNECTED("Connected"),
    RECONNECTING("Reconnecting..."),
    ERROR("Connection Error")
}

data class DiscordUser(
    val id: String = "",
    val username: String = "",
    val globalName: String = "",
    val avatarUrl: String = ""
) {
    val displayName: String
        get() = globalName.ifBlank { username.ifBlank { "Discord User" } }
}

data class RichPresencePayload(
    val applicationId: String = DEFAULT_DISCORD_APP_ID,
    val name: String = "PulseRPC",
    val details: String = "",
    val state: String = "",
    val activityType: ActivityType = ActivityType.PLAYING,
    val largeImageUrl: String = "",
    val largeImageText: String = "",
    val smallImageUrl: String = "",
    val smallImageText: String = "",
    val startTimestampMs: Long? = null,
    val button1Label: String = "",
    val button1Url: String = "",
    val button2Label: String = "",
    val button2Url: String = "",
    val sourcePackageName: String? = null,
    val sourceLabel: String = "Standby",
    val isStandby: Boolean = false,
    val graceRemainingSeconds: Int? = null
) {
    companion object {
        const val DEFAULT_DISCORD_APP_ID = "962990036020756480"
    }
}

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val isGame: Boolean,
    val icon: Drawable?
)

data class MediaTrackInfo(
    val packageName: String,
    val playerName: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val isPlaying: Boolean = true,
    val updatedAtMs: Long = System.currentTimeMillis()
)

data class PermissionStatus(
    val hasUsageStats: Boolean = false,
    val hasNotificationListener: Boolean = false,
    val hasPostNotifications: Boolean = false
)

data class GatewayState(
    val status: GatewayStatus = GatewayStatus.DISCONNECTED,
    val user: DiscordUser? = null,
    val pingMs: Long? = null,
    val errorMessage: String? = null,
    val lastPresenceSentAtMs: Long? = null
)
