package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import com.example.data.local.ActivityLogEntity
import com.example.data.local.AppRuleEntity
import com.example.data.local.PreferencesManager
import com.example.data.local.PresencePresetEntity
import com.example.data.local.PulseRpcDao
import com.example.data.local.UserPreferences
import com.example.data.model.ActivityType
import com.example.data.model.BroadcastMode
import com.example.data.model.GatewayState
import com.example.data.model.InstalledAppInfo
import com.example.data.model.MediaTrackInfo
import com.example.data.model.PermissionStatus
import com.example.data.model.RichPresencePayload
import com.example.data.remote.AppIconUrlResolver
import com.example.data.remote.DiscordGatewayClient
import com.example.service.DetectedForegroundApp
import com.example.service.ForegroundAppDetector
import com.example.service.MediaStateHolder
import com.example.service.SystemPermissionHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PresenceRepository(
    private val context: Context,
    private val dao: PulseRpcDao,
    val preferencesManager: PreferencesManager,
    val gatewayClient: DiscordGatewayClient
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val detector = ForegroundAppDetector(context)
    private val iconResolver = AppIconUrlResolver()

    val preferencesFlow: Flow<UserPreferences> = preferencesManager.preferencesFlow
    val appRulesFlow: Flow<List<AppRuleEntity>> = dao.observeAllAppRules()
    val presetsFlow: Flow<List<PresencePresetEntity>> = dao.observePresets()
    val recentLogsFlow: Flow<List<ActivityLogEntity>> = dao.observeRecentLogs()
    val gatewayStateFlow: StateFlow<GatewayState> = gatewayClient.gatewayState
    val currentMediaFlow: StateFlow<MediaTrackInfo?> = MediaStateHolder.currentMedia

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _activePresence = MutableStateFlow(
        RichPresencePayload(
            name = "Standby",
            details = "Hidden on your Discord profile",
            state = "Open an enabled app to go live",
            sourceLabel = "Standby",
            isStandby = true
        )
    )
    val activePresence: StateFlow<RichPresencePayload> = _activePresence.asStateFlow()

    private val _detectedApp = MutableStateFlow<DetectedForegroundApp?>(null)
    val detectedApp: StateFlow<DetectedForegroundApp?> = _detectedApp.asStateFlow()

    private val _manualPreviewApp = MutableStateFlow<InstalledAppInfo?>(null)
    val manualPreviewApp: StateFlow<InstalledAppInfo?> = _manualPreviewApp.asStateFlow()

    private val _permissions = MutableStateFlow(SystemPermissionHelper.checkPermissions(context))
    val permissions: StateFlow<PermissionStatus> = _permissions.asStateFlow()

    private var lastSessionSignature: String? = null
    private var currentSessionStartMs: Long = System.currentTimeMillis()
    private var lastAppliedElapsedVersion: Long = -1L

    // Grace-period & session-continuation state for AUTO_APP mode
    private var lastLiveAppPackage: String? = null
    private var lastLiveAppPayload: RichPresencePayload? = null
    private var appLeftAtMs: Long? = null
    private var pausedSessionPkg: String? = null
    private var pausedSessionElapsedMs: Long = 0L

    private val defaultExcludedPackages = setOf(
        "com.android.settings",
        "com.android.systemui",
        "com.android.vending",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller"
    )

    init {
        scope.launch {
            refreshInstalledApps()
        }
    }

    fun refreshPermissions() {
        _permissions.value = SystemPermissionHelper.checkPermissions(context)
    }

    suspend fun refreshInstalledApps() {
        val loaded = withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(launcherIntent, 0)
            }

            val seen = HashSet<String>()
            resolveInfos.mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                if (!seen.add(pkg)) return@mapNotNull null
                if (pkg == context.packageName || detector.isLauncherPackage(pkg)) return@mapNotNull null
                val appName = info.loadLabel(pm).toString().ifBlank { pkg }
                val appInfo = info.activityInfo?.applicationInfo
                val isGame = if (appInfo != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        appInfo.category == ApplicationInfo.CATEGORY_GAME
                    } else {
                        @Suppress("DEPRECATION")
                        (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                    }
                } else false

                val icon = runCatching { info.loadIcon(pm) }.getOrNull()
                InstalledAppInfo(
                    packageName = pkg,
                    appName = appName,
                    isGame = isGame,
                    icon = icon
                )
            }.sortedBy { it.appName.lowercase() }
        }

        _installedApps.value = loaded

        val defaultEntities = loaded.map { app ->
            val shouldEnableByDefault = !defaultExcludedPackages.contains(app.packageName)
            AppRuleEntity(
                packageName = app.packageName,
                appName = app.appName,
                isEnabled = shouldEnableByDefault,
                activityTypeCode = ActivityType.PLAYING.code
            )
        }
        dao.insertMissingAppRules(defaultEntities)
    }

    fun selectPreviewApp(app: InstalledAppInfo?) {
        _manualPreviewApp.value = app
        scope.launch {
            pollAndSyncPresence(logChanges = false)
        }
    }

    suspend fun setBroadcastMode(mode: BroadcastMode) {
        preferencesManager.setBroadcastMode(mode)
        if (mode != BroadcastMode.AUTO_APP) {
            _manualPreviewApp.value = null
            clearGraceState()
        }
        pollAndSyncPresence(logChanges = true)
    }

    suspend fun saveAppRule(rule: AppRuleEntity) {
        dao.upsertAppRule(rule.copy(updatedAtMs = System.currentTimeMillis()))
        pollAndSyncPresence(logChanges = false)
    }

    suspend fun toggleAppEnabled(packageName: String, appName: String, enabled: Boolean) {
        val existing = dao.getAppRule(packageName)
        val updated = existing?.copy(isEnabled = enabled, updatedAtMs = System.currentTimeMillis())
            ?: AppRuleEntity(packageName = packageName, appName = appName, isEnabled = enabled)
        dao.upsertAppRule(updated)
        pollAndSyncPresence(logChanges = false)
    }

    suspend fun setBatchAppEnabled(filterGamesOnly: Boolean?, enabled: Boolean) {
        val apps = _installedApps.value
        for (app in apps) {
            if (filterGamesOnly == true && !app.isGame) {
                val existing = dao.getAppRule(app.packageName)
                val updated = existing?.copy(isEnabled = false, updatedAtMs = System.currentTimeMillis())
                    ?: AppRuleEntity(packageName = app.packageName, appName = app.appName, isEnabled = false)
                dao.upsertAppRule(updated)
            } else if (filterGamesOnly == true && app.isGame) {
                val existing = dao.getAppRule(app.packageName)
                val updated = existing?.copy(isEnabled = true, updatedAtMs = System.currentTimeMillis())
                    ?: AppRuleEntity(packageName = app.packageName, appName = app.appName, isEnabled = true)
                dao.upsertAppRule(updated)
            } else if (filterGamesOnly == null) {
                val existing = dao.getAppRule(app.packageName)
                val updated = existing?.copy(isEnabled = enabled, updatedAtMs = System.currentTimeMillis())
                    ?: AppRuleEntity(packageName = app.packageName, appName = app.appName, isEnabled = enabled)
                dao.upsertAppRule(updated)
            }
        }
        pollAndSyncPresence(logChanges = false)
    }

    suspend fun saveCustomRpc(payload: RichPresencePayload, broadcastNow: Boolean) {
        preferencesManager.saveCustomRpc(payload)
        if (broadcastNow) {
            preferencesManager.setBroadcastMode(BroadcastMode.CUSTOM)
            clearGraceState()
        }
        pollAndSyncPresence(logChanges = broadcastNow)
    }

    suspend fun savePreset(preset: PresencePresetEntity): Long {
        return dao.upsertPreset(preset)
    }

    suspend fun deletePreset(id: Long) {
        dao.deletePresetById(id)
    }

    suspend fun applyPreset(preset: PresencePresetEntity, broadcastNow: Boolean) {
        val payload = RichPresencePayload(
            applicationId = preset.applicationId,
            name = preset.activityName,
            details = preset.details,
            state = preset.state,
            activityType = ActivityType.fromCode(preset.activityTypeCode),
            largeImageUrl = preset.largeImageUrl,
            largeImageText = preset.largeImageText,
            smallImageUrl = preset.smallImageUrl,
            smallImageText = preset.smallImageText,
            startTimestampMs = if (preset.showElapsedTime) System.currentTimeMillis() else null,
            button1Label = preset.button1Label,
            button1Url = preset.button1Url,
            button2Label = preset.button2Label,
            button2Url = preset.button2Url
        )
        saveCustomRpc(payload, broadcastNow)
    }

    suspend fun clearLogs() {
        dao.clearLogs()
    }

    suspend fun connectDiscord(token: String) {
        preferencesManager.saveDiscordToken(token)
        val prefs = preferencesFlow.first()
        val current = _activePresence.value
        val initialForGateway = if (prefs.isBroadcastingActive && !current.isStandby) current else null
        gatewayClient.connect(token, prefs.autoReconnect, initialForGateway)
    }

    suspend fun disconnectDiscord() {
        gatewayClient.disconnect()
        preferencesManager.saveCachedUser(null)
    }

    private fun clearGraceState() {
        lastLiveAppPackage = null
        lastLiveAppPayload = null
        appLeftAtMs = null
    }

    suspend fun pollAndSyncPresence(logChanges: Boolean = true): RichPresencePayload {
        refreshPermissions()
        val prefs = preferencesFlow.first()
        val now = System.currentTimeMillis()
        val ignorePkg = if (prefs.ignoreSelfApp) context.packageName else null
        val detected = detector.detectCurrentApp(ignorePkg)
        _detectedApp.value = detected

        // Re-anchor timer immediately whenever the user modifies Custom Elapsed Offset
        val elapsedVersionChanged = lastAppliedElapsedVersion != -1L &&
            prefs.customElapsedVersion != lastAppliedElapsedVersion
        if (lastAppliedElapsedVersion == -1L || elapsedVersionChanged) {
            lastAppliedElapsedVersion = prefs.customElapsedVersion
            if (elapsedVersionChanged) {
                currentSessionStartMs = computeStartTimestamp(now, prefs)
                pausedSessionElapsedMs = if (prefs.customElapsedEnabled) prefs.customElapsedOffsetMs else 0L
                lastLiveAppPayload = lastLiveAppPayload?.copy(startTimestampMs = currentSessionStartMs)
            }
        }

        val resolved = resolvePayload(prefs, detected, now)

        val signature = "${prefs.broadcastMode.name}|${resolved.isStandby}|${resolved.sourcePackageName}|${resolved.name}|${resolved.details}|${resolved.state}"
        val changed = signature != lastSessionSignature
        if (changed) {
            lastSessionSignature = signature
            if (resolved.graceRemainingSeconds == null) {
                // Only compute a fresh start timestamp if we didn't just resume a paused session or carry over grace
                currentSessionStartMs = resolved.startTimestampMs ?: computeStartTimestamp(now, prefs)
            }
            if (logChanges && prefs.isBroadcastingActive && !resolved.isStandby && resolved.graceRemainingSeconds == null) {
                dao.insertLog(
                    ActivityLogEntity(
                        packageName = resolved.sourcePackageName ?: "custom.rpc",
                        title = resolved.name,
                        subtitle = resolved.details.ifBlank { resolved.state.ifBlank { resolved.activityType.prefixLabel } },
                        modeLabel = prefs.broadcastMode.label
                    )
                )
            }
        }

        val finalPayload = if (!resolved.isStandby &&
            prefs.showElapsedTimer &&
            resolved.startTimestampMs == null &&
            shouldAttachElapsed(prefs)
        ) {
            resolved.copy(startTimestampMs = currentSessionStartMs)
        } else {
            resolved
        }

        _activePresence.value = finalPayload

        if (prefs.isBroadcastingActive && !finalPayload.isStandby) {
            gatewayClient.sendPresence(finalPayload)
        } else {
            gatewayClient.sendPresence(null)
        }

        return finalPayload
    }

    private fun computeStartTimestamp(now: Long, prefs: UserPreferences): Long {
        val offsetMs = if (prefs.customElapsedEnabled) prefs.customElapsedOffsetMs else 0L
        return now - offsetMs
    }

    private fun shouldAttachElapsed(prefs: UserPreferences): Boolean {
        return when (prefs.broadcastMode) {
            BroadcastMode.CUSTOM -> prefs.customShowElapsed
            else -> true
        }
    }

    private suspend fun resolvePayload(
        prefs: UserPreferences,
        detected: DetectedForegroundApp?,
        now: Long
    ): RichPresencePayload {
        return when (prefs.broadcastMode) {
            BroadcastMode.CUSTOM -> {
                val startMs = if (prefs.customShowElapsed) {
                    if (lastSessionSignature?.startsWith("${BroadcastMode.CUSTOM.name}|false") == true) {
                        currentSessionStartMs
                    } else {
                        computeStartTimestamp(now, prefs)
                    }
                } else null
                RichPresencePayload(
                    applicationId = prefs.customAppId,
                    name = prefs.customName.ifBlank { "PulseRPC" },
                    details = prefs.customDetails,
                    state = prefs.customState,
                    activityType = ActivityType.fromCode(prefs.customTypeCode),
                    largeImageUrl = prefs.customLargeImageUrl,
                    largeImageText = prefs.customLargeImageText,
                    smallImageUrl = prefs.customSmallImageUrl,
                    smallImageText = prefs.customSmallImageText,
                    startTimestampMs = startMs,
                    button1Label = prefs.customButton1Label,
                    button1Url = prefs.customButton1Url,
                    button2Label = prefs.customButton2Label,
                    button2Url = prefs.customButton2Url,
                    sourcePackageName = "custom.studio",
                    sourceLabel = "Custom Studio",
                    isStandby = false
                )
            }

            BroadcastMode.MEDIA -> {
                val media = MediaStateHolder.currentMedia.value
                if (media != null && media.title.isNotBlank() && media.isPlaying) {
                    val resolvedMedia = iconResolver.resolveAppLogo(media.packageName)
                    val startMs = if (prefs.showElapsedTimer) {
                        if (prefs.customElapsedEnabled) {
                            now - prefs.customElapsedOffsetMs
                        } else {
                            media.updatedAtMs
                        }
                    } else null
                    RichPresencePayload(
                        applicationId = resolvedMedia?.discordAppId ?: prefs.defaultApplicationId,
                        name = media.playerName,
                        details = media.title,
                        state = "by ${media.artist}",
                        activityType = ActivityType.LISTENING,
                        largeImageUrl = resolvedMedia?.iconUrl.orEmpty(),
                        largeImageText = media.album.ifBlank { media.playerName },
                        startTimestampMs = startMs,
                        sourcePackageName = media.packageName,
                        sourceLabel = "Media Active (${media.playerName})",
                        isStandby = false
                    )
                } else {
                    RichPresencePayload(
                        applicationId = prefs.defaultApplicationId,
                        name = "Music Player",
                        details = "No active playback",
                        state = if (_permissions.value.hasNotificationListener) {
                            "Hidden on Discord until music plays"
                        } else {
                            "Grant Notification Access to detect music"
                        },
                        activityType = ActivityType.LISTENING,
                        startTimestampMs = null,
                        sourcePackageName = null,
                        sourceLabel = "Media Standby",
                        isStandby = true
                    )
                }
            }

            BroadcastMode.AUTO_APP -> {
                val manual = _manualPreviewApp.value
                val targetPkg = detected?.packageName ?: manual?.packageName
                val targetName = detected?.appName ?: manual?.appName
                val isGame = detected?.isGame ?: manual?.isGame ?: false
                val isPreview = detected == null && manual != null

                if (targetPkg != null && targetName != null) {
                    val rule = dao.getAppRule(targetPkg)
                    if (rule != null && !rule.isEnabled && !isPreview) {
                        handleAppLeftOrDisabled(prefs, now)
                    } else {
                        // User is inside an enabled app (or previewing one)
                        val isResumingSameDuringGrace = lastLiveAppPackage == targetPkg && appLeftAtMs != null
                        val isResumingAfterExpiry = !isResumingSameDuringGrace &&
                            prefs.keepPresenceOnLeaveEnabled &&
                            pausedSessionPkg == targetPkg &&
                            pausedSessionElapsedMs > 0L

                        val sessionStart = when {
                            isResumingSameDuringGrace -> currentSessionStartMs
                            lastLiveAppPackage == targetPkg && appLeftAtMs == null -> currentSessionStartMs
                            isResumingAfterExpiry -> now - pausedSessionElapsedMs
                            else -> computeStartTimestamp(now, prefs)
                        }
                        currentSessionStartMs = sessionStart
                        appLeftAtMs = null

                        val customImg = rule?.largeImageUrl?.trim().orEmpty()
                        val resolvedLogo = if (customImg.isBlank()) {
                            iconResolver.resolveAppLogo(targetPkg)
                        } else null

                        val effectiveLargeImage = customImg.ifBlank { resolvedLogo?.iconUrl.orEmpty() }
                        val effectiveAppId = when {
                            rule != null && rule.isCustomized && rule.applicationId.isNotBlank() -> rule.applicationId
                            !resolvedLogo?.discordAppId.isNullOrBlank() -> resolvedLogo?.discordAppId!!
                            else -> prefs.defaultApplicationId
                        }

                        val built = if (rule != null && rule.isCustomized) {
                            RichPresencePayload(
                                applicationId = effectiveAppId,
                                name = rule.customTitle.ifBlank { targetName },
                                details = rule.customDetails.ifBlank { if (isGame) "In Game" else "Active on Android" },
                                state = rule.customState,
                                activityType = ActivityType.fromCode(rule.activityTypeCode),
                                largeImageUrl = effectiveLargeImage,
                                largeImageText = rule.largeImageText.ifBlank { targetName },
                                smallImageUrl = rule.smallImageUrl,
                                smallImageText = rule.smallImageText,
                                startTimestampMs = if (rule.showElapsedTime && prefs.showElapsedTimer) sessionStart else null,
                                button1Label = rule.button1Label,
                                button1Url = rule.button1Url,
                                sourcePackageName = targetPkg,
                                sourceLabel = if (isPreview) "App Test Preview" else "Live App Detection",
                                isStandby = false
                            )
                        } else {
                            RichPresencePayload(
                                applicationId = effectiveAppId,
                                name = targetName,
                                details = if (isGame) "Playing on Mobile" else "Using $targetName",
                                state = if (isPreview) "Selected App Preview" else "Android Device",
                                activityType = ActivityType.PLAYING,
                                largeImageUrl = effectiveLargeImage,
                                largeImageText = targetName,
                                startTimestampMs = if (prefs.showElapsedTimer) sessionStart else null,
                                sourcePackageName = targetPkg,
                                sourceLabel = if (isPreview) "App Test Preview" else "Live App Detection",
                                isStandby = false
                            )
                        }

                        if (!isPreview) {
                            lastLiveAppPackage = targetPkg
                            lastLiveAppPayload = built
                            pausedSessionPkg = targetPkg
                            pausedSessionElapsedMs = (now - sessionStart).coerceAtLeast(0L)
                        }
                        built
                    }
                } else {
                    handleAppLeftOrDisabled(prefs, now)
                }
            }
        }
    }

    private fun handleAppLeftOrDisabled(
        prefs: UserPreferences,
        now: Long
    ): RichPresencePayload {
        val heldPayload = lastLiveAppPayload
        val heldPkg = lastLiveAppPackage
        if (prefs.keepPresenceOnLeaveEnabled && heldPayload != null && heldPkg != null) {
            val leftStart = appLeftAtMs ?: now.also {
                appLeftAtMs = it
                pausedSessionPkg = heldPkg
                pausedSessionElapsedMs = (it - currentSessionStartMs).coerceAtLeast(0L)
            }
            val delayMs = prefs.leaveDelaySeconds * 1000L
            val elapsedSinceLeave = now - leftStart
            if (elapsedSinceLeave < delayMs) {
                val remainingSec = (((delayMs - elapsedSinceLeave) + 999L) / 1000L).toInt().coerceAtLeast(1)
                return heldPayload.copy(
                    sourceLabel = "Grace period (${remainingSec}s left)",
                    isStandby = false,
                    graceRemainingSeconds = remainingSec
                )
            } else {
                // Grace period expired: keep pausedSessionPkg + pausedSessionElapsedMs so reopening the same app continues from where left!
                clearGraceState()
            }
        } else {
            clearGraceState()
        }

        return RichPresencePayload(
            applicationId = prefs.defaultApplicationId,
            name = "Standby",
            details = if (_permissions.value.hasUsageStats) {
                "Hidden on Discord until you open an app"
            } else {
                "Grant Usage Access to detect active apps"
            },
            state = "Nothing shown on your profile right now",
            activityType = ActivityType.PLAYING,
            startTimestampMs = null,
            sourcePackageName = null,
            sourceLabel = if (_permissions.value.hasUsageStats) "Standby • Hidden on Discord" else "Usage Access Needed",
            isStandby = true
        )
    }
}
