package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand & Semantic Tokens
val Blurple = Color(0xFF5865F2)
val BlurpleBright = Color(0xFF7983F5)
val BlurpleDark = Color(0xFF4752C4)
val BlurpleContainerDark = Color(0xFF232756)

val NeonCyan = Color(0xFF38BDF8)
val NeonCyanContainerDark = Color(0xFF14354B)

val OnlineGreen = Color(0xFF23A55A)
val OnlineGreenBright = Color(0xFF3DD67C)
val OnlineGreenContainerDark = Color(0xFF133623)

val IdleAmber = Color(0xFFF0B232)
val IdleAmberContainerDark = Color(0xFF3D2E10)

val AlertCoral = Color(0xFFF23F43)
val AlertCoralContainerDark = Color(0xFF44161A)

// Dark OLED Surfaces
val MidnightBg = Color(0xFF0C0D14)
val MidnightSurface = Color(0xFF131520)
val MidnightSurfaceVariant = Color(0xFF1B1E2E)
val MidnightCard = Color(0xFF1E2133)
val MidnightCardElevated = Color(0xFF252940)
val MidnightOutline = Color(0xFF2F3450)
val TextPrimaryDark = Color(0xFFF2F3F8)
val TextSecondaryDark = Color(0xFFA7ACC4)

// Light Surfaces
val CloudBg = Color(0xFFF5F6FA)
val CloudSurface = Color(0xFFFFFFFF)
val CloudSurfaceVariant = Color(0xFFEBEEF7)
val CloudOutline = Color(0xFFD5DAE8)
val TextPrimaryLight = Color(0xFF121420)
val TextSecondaryLight = Color(0xFF545A72)
