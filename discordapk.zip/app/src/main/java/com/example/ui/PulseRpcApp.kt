package com.example.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Cable
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Cable
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.service.SystemPermissionHelper
import com.example.ui.screens.AppsScreen
import com.example.ui.screens.ConnectScreen
import com.example.ui.screens.LiveDashboardScreen
import com.example.ui.screens.StudioScreen
import com.example.ui.theme.Blurple

object PulseRoutes {
    const val LIVE = "live"
    const val APPS = "apps"
    const val STUDIO = "studio"
    const val CONNECT = "connect"
}

private enum class PulseDestination(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    LIVE(PulseRoutes.LIVE, "Live", Icons.Rounded.Sensors, Icons.Outlined.Sensors),
    APPS(PulseRoutes.APPS, "Apps", Icons.Rounded.Apps, Icons.Outlined.Apps),
    STUDIO(PulseRoutes.STUDIO, "Studio", Icons.Rounded.Tune, Icons.Outlined.Tune),
    CONNECT(PulseRoutes.CONNECT, "Connect", Icons.Rounded.Cable, Icons.Outlined.Cable)
}

@Composable
fun PulseRpcApp(
    viewModel: MainViewModel
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: PulseRoutes.LIVE
    val snackbarHostState = remember { SnackbarHostState() }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refreshOnResume()
        if (granted) {
            viewModel.toggleBroadcast(true)
        }
    }

    LaunchedEffect(Unit) {
        viewModel.uiMessages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        PulseDestination.entries.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label
                                    )
                                },
                                label = { Text(dest.label) },
                                modifier = Modifier.testTag("nav_item_${dest.route}"),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Blurple,
                                    selectedTextColor = Blurple,
                                    indicatorColor = Blurple.copy(alpha = 0.16f)
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        PulseDestination.entries.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label
                                    )
                                },
                                label = { Text(dest.label) },
                                modifier = Modifier.testTag("rail_item_${dest.route}")
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = PulseRoutes.LIVE,
                    modifier = Modifier.weight(1f)
                ) {
                    composable(PulseRoutes.LIVE) {
                        LiveDashboardScreen(
                            uiState = uiState,
                            onToggleBroadcast = { enable ->
                                if (enable &&
                                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                    !uiState.permissions.hasPostNotifications
                                ) {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    viewModel.toggleBroadcast(enable)
                                }
                            },
                            onSelectMode = viewModel::setBroadcastMode,
                            onToggleKeepOnLeave = viewModel::setKeepPresenceOnLeave,
                            onSetLeaveDelaySeconds = viewModel::setLeaveDelaySeconds,
                            onSetCustomElapsed = viewModel::setCustomElapsed,
                            onOpenUsageSettings = {
                                runCatching {
                                    context.startActivity(SystemPermissionHelper.createUsageAccessSettingsIntent())
                                }
                            },
                            onOpenNotificationListenerSettings = {
                                runCatching {
                                    context.startActivity(
                                        SystemPermissionHelper.createNotificationListenerSettingsIntent()
                                    )
                                }
                            },
                            onRequestPostNotifications = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            },
                            onNavigateToConnect = { navigateTo(PulseRoutes.CONNECT) },
                            onSelectPreviewApp = viewModel::selectPreviewApp,
                            onNavigateToApps = { navigateTo(PulseRoutes.APPS) }
                        )
                    }

                    composable(PulseRoutes.APPS) {
                        AppsScreen(
                            uiState = uiState,
                            onToggleAppEnabled = viewModel::toggleAppEnabled,
                            onBatchToggle = viewModel::setBatchAppEnabled,
                            onSaveAppRule = viewModel::saveAppRule,
                            onPreviewApp = { app ->
                                viewModel.selectPreviewApp(app)
                                navigateTo(PulseRoutes.LIVE)
                            },
                            onRefreshApps = viewModel::refreshInstalledApps
                        )
                    }

                    composable(PulseRoutes.STUDIO) {
                        StudioScreen(
                            uiState = uiState,
                            onApplyCustomRpc = { payload, goLive ->
                                viewModel.saveCustomRpc(payload, goLive)
                                if (goLive) navigateTo(PulseRoutes.LIVE)
                            },
                            onSavePreset = viewModel::savePreset,
                            onDeletePreset = viewModel::deletePreset,
                            onApplyPreset = viewModel::applyPreset
                        )
                    }

                    composable(PulseRoutes.CONNECT) {
                        ConnectScreen(
                            uiState = uiState,
                            onConnectDiscord = viewModel::connectDiscord,
                            onDisconnectDiscord = viewModel::disconnectDiscord,
                            onSetPollingInterval = viewModel::setPollingIntervalSec,
                            onSetShowElapsed = viewModel::setShowElapsedTimer,
                            onSetIgnoreSelf = viewModel::setIgnoreSelfApp,
                            onSetAutoReconnect = viewModel::setAutoReconnect,
                            onSetKeepPresenceOnLeave = viewModel::setKeepPresenceOnLeave,
                            onSetLeaveDelaySeconds = viewModel::setLeaveDelaySeconds,
                            onSetCustomElapsed = viewModel::setCustomElapsed,
                            onSetDefaultAppId = viewModel::setDefaultApplicationId,
                            onClearLogs = viewModel::clearLogs
                        )
                    }
                }
            }
        }
    }
}
