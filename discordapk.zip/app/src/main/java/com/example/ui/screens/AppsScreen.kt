package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Preview
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.example.data.local.AppRuleEntity
import com.example.data.model.ActivityType
import com.example.data.model.InstalledAppInfo
import com.example.data.model.RichPresencePayload
import com.example.ui.MainUiState
import com.example.ui.theme.Blurple
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.OnlineGreenBright

private enum class AppFilter(val label: String) {
    ALL("All"),
    GAMES("Games"),
    ENABLED("Enabled"),
    CUSTOMIZED("Customized")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(
    uiState: MainUiState,
    onToggleAppEnabled: (String, String, Boolean) -> Unit,
    onBatchToggle: (Boolean?, Boolean) -> Unit,
    onSaveAppRule: (AppRuleEntity) -> Unit,
    onPreviewApp: (InstalledAppInfo) -> Unit,
    onRefreshApps: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(AppFilter.ALL) }
    var editingApp by remember { mutableStateOf<InstalledAppInfo?>(null) }

    val filteredApps = remember(uiState.installedApps, uiState.appRules, searchQuery, selectedFilter) {
        uiState.installedApps.filter { app ->
            val rule = uiState.appRules[app.packageName]
            val matchesQuery = searchQuery.isBlank() ||
                app.appName.contains(searchQuery, ignoreCase = true) ||
                app.packageName.contains(searchQuery, ignoreCase = true)
            val matchesFilter = when (selectedFilter) {
                AppFilter.ALL -> true
                AppFilter.GAMES -> app.isGame
                AppFilter.ENABLED -> rule?.isEnabled ?: true
                AppFilter.CUSTOMIZED -> rule?.isCustomized == true
            }
            matchesQuery && matchesFilter
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Detected Apps",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Toggle auto-broadcast or customize RPC text per app",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(
                    onClick = onRefreshApps,
                    modifier = Modifier.testTag("refresh_apps_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "Refresh installed apps"
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("apps_search_input"),
                placeholder = { Text("Search installed apps or packages...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Rounded.Clear, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(AppFilter.entries) { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter.label) },
                        modifier = Modifier.testTag("app_filter_${filter.name.lowercase()}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onBatchToggle(true, true) },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text("Games Only", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                }
                OutlinedButton(
                    onClick = { onBatchToggle(null, true) },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text("Enable All", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                }
                OutlinedButton(
                    onClick = { onBatchToggle(null, false) },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text("Disable All", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (filteredApps.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Apps,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = "No matching apps found",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Try clearing your search filter or refreshing the device app list.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredApps, key = { it.packageName }) { app ->
                        val rule = uiState.appRules[app.packageName]
                        val isEnabled = rule?.isEnabled ?: true
                        val isCustomized = rule?.isCustomized == true

                        AppRuleRow(
                            app = app,
                            rule = rule,
                            isEnabled = isEnabled,
                            isCustomized = isCustomized,
                            onToggleEnabled = { checked ->
                                onToggleAppEnabled(app.packageName, app.appName, checked)
                            },
                            onPreview = { onPreviewApp(app) },
                            onEdit = { editingApp = app }
                        )
                    }
                }
            }
        }
    }

    editingApp?.let { targetApp ->
        val existingRule = uiState.appRules[targetApp.packageName]
            ?: AppRuleEntity(packageName = targetApp.packageName, appName = targetApp.appName)

        AppRuleEditorSheet(
            app = targetApp,
            initialRule = existingRule,
            onDismiss = { editingApp = null },
            onSave = { updated ->
                onSaveAppRule(updated)
                editingApp = null
            }
        )
    }
}

@Composable
private fun AppRuleRow(
    app: InstalledAppInfo,
    rule: AppRuleEntity?,
    isEnabled: Boolean,
    isCustomized: Boolean,
    onToggleEnabled: (Boolean) -> Unit,
    onPreview: () -> Unit,
    onEdit: () -> Unit
) {
    val iconBitmap = remember(app.packageName) {
        app.icon?.let { runCatching { it.toBitmap(96, 96).asImageBitmap() }.getOrNull() }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("app_rule_card_${app.packageName}"),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(
            1.dp,
            if (isCustomized) Blurple.copy(alpha = 0.55f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
        )
    ) {
        Row(
            modifier = Modifier
                .clickable(onClick = onEdit)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (iconBitmap != null) {
                Image(
                    bitmap = iconBitmap,
                    contentDescription = app.appName,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Fit
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Apps, contentDescription = null)
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = rule?.customTitle?.ifBlank { app.appName } ?: app.appName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (app.isGame) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = NeonCyan.copy(alpha = 0.16f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.SportsEsports,
                                contentDescription = "Game",
                                tint = NeonCyan,
                                modifier = Modifier
                                    .padding(4.dp)
                                    .size(13.dp)
                            )
                        }
                    }
                    if (isCustomized) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Blurple.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "CUSTOM",
                                style = MaterialTheme.typography.labelSmall,
                                color = Blurple,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Text(
                    text = if (isCustomized && !rule?.customDetails.isNullOrBlank()) {
                        rule?.customDetails.orEmpty()
                    } else {
                        app.packageName
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(
                onClick = onPreview,
                modifier = Modifier.testTag("preview_app_${app.packageName}")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Preview,
                    contentDescription = "Preview ${app.appName}",
                    tint = OnlineGreenBright
                )
            }

            IconButton(
                onClick = onEdit,
                modifier = Modifier.testTag("edit_app_${app.packageName}")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Edit,
                    contentDescription = "Customize ${app.appName}",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Switch(
                checked = isEnabled,
                onCheckedChange = onToggleEnabled,
                modifier = Modifier.testTag("toggle_app_${app.packageName}")
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppRuleEditorSheet(
    app: InstalledAppInfo,
    initialRule: AppRuleEntity,
    onDismiss: () -> Unit,
    onSave: (AppRuleEntity) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var title by remember { mutableStateOf(initialRule.customTitle.ifBlank { app.appName }) }
    var details by remember { mutableStateOf(initialRule.customDetails) }
    var state by remember { mutableStateOf(initialRule.customState) }
    var selectedType by remember { mutableStateOf(ActivityType.fromCode(initialRule.activityTypeCode)) }
    var largeImageUrl by remember { mutableStateOf(initialRule.largeImageUrl) }
    var buttonLabel by remember { mutableStateOf(initialRule.button1Label) }
    var buttonUrl by remember { mutableStateOf(initialRule.button1Url) }
    var appId by remember { mutableStateOf(initialRule.applicationId) }
    var showElapsed by remember { mutableStateOf(initialRule.showElapsedTime) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surfaceContainer
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Customize ${app.appName}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = app.packageName,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ActivityType.entries) { type ->
                    FilterChip(
                        selected = selectedType == type,
                        onClick = { selectedType = type },
                        label = { Text(type.prefixLabel) }
                    )
                }
            }

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Display Title") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = details,
                onValueChange = { details = it },
                label = { Text("Details (Line 1)") },
                placeholder = { Text("e.g., Ranked Lobby • Duo") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = state,
                onValueChange = { state = it },
                label = { Text("State (Line 2)") },
                placeholder = { Text("e.g., Playing on Mobile") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = largeImageUrl,
                onValueChange = { largeImageUrl = it },
                label = { Text("Large Artwork URL or Discord Asset Key") },
                placeholder = { Text("https://... or asset_key") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = appId,
                onValueChange = { appId = it },
                label = { Text("Discord Application ID") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = buttonLabel,
                    onValueChange = { buttonLabel = it },
                    label = { Text("Button Label") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = buttonUrl,
                    onValueChange = { buttonUrl = it },
                    label = { Text("Button URL") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Show Elapsed Timestamp", style = MaterialTheme.typography.bodyLarge)
                Switch(checked = showElapsed, onCheckedChange = { showElapsed = it })
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        onSave(
                            AppRuleEntity(
                                packageName = app.packageName,
                                appName = app.appName,
                                isEnabled = initialRule.isEnabled,
                                isCustomized = false,
                                applicationId = RichPresencePayload.DEFAULT_DISCORD_APP_ID
                            )
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) {
                    Text("Reset")
                }

                Button(
                    onClick = {
                        onSave(
                            initialRule.copy(
                                isCustomized = true,
                                customTitle = title.trim(),
                                customDetails = details.trim(),
                                customState = state.trim(),
                                activityTypeCode = selectedType.code,
                                largeImageUrl = largeImageUrl.trim(),
                                button1Label = buttonLabel.trim(),
                                button1Url = buttonUrl.trim(),
                                applicationId = appId.trim().ifBlank { RichPresencePayload.DEFAULT_DISCORD_APP_ID },
                                showElapsedTime = showElapsed
                            )
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("save_app_rule_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Blurple,
                        contentColor = Color.White
                    )
                ) {
                    Text("Save Rule")
                }
            }
        }
    }
}
