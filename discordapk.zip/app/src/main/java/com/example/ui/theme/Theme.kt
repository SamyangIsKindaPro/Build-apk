package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val PulseDarkColorScheme = darkColorScheme(
    primary = Blurple,
    onPrimary = Color.White,
    primaryContainer = BlurpleContainerDark,
    onPrimaryContainer = BlurpleBright,
    secondary = NeonCyan,
    onSecondary = Color(0xFF062030),
    secondaryContainer = NeonCyanContainerDark,
    onSecondaryContainer = NeonCyan,
    tertiary = OnlineGreenBright,
    onTertiary = Color(0xFF042110),
    tertiaryContainer = OnlineGreenContainerDark,
    onTertiaryContainer = OnlineGreenBright,
    background = MidnightBg,
    onBackground = TextPrimaryDark,
    surface = MidnightSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = MidnightSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    surfaceContainerLowest = MidnightBg,
    surfaceContainerLow = MidnightSurface,
    surfaceContainer = MidnightCard,
    surfaceContainerHigh = MidnightCardElevated,
    outline = MidnightOutline,
    outlineVariant = Color(0xFF25293E),
    error = AlertCoral,
    onError = Color.White,
    errorContainer = AlertCoralContainerDark,
    onErrorContainer = Color(0xFFFFB4B5)
)

private val PulseLightColorScheme = lightColorScheme(
    primary = Blurple,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE1E4FF),
    onPrimaryContainer = BlurpleDark,
    secondary = Color(0xFF0284C7),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF075985),
    tertiary = OnlineGreen,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFD9F7E5),
    onTertiaryContainer = Color(0xFF0A4725),
    background = CloudBg,
    onBackground = TextPrimaryLight,
    surface = CloudSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = CloudSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    surfaceContainer = CloudSurface,
    surfaceContainerHigh = CloudSurfaceVariant,
    outline = CloudOutline,
    error = AlertCoral,
    onError = Color.White
)

val PulseShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun PulseRpcTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) PulseDarkColorScheme else PulseLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = PulseTypography,
        shapes = PulseShapes,
        content = content
    )
}
