package com.example.ui

import android.app.Application
import android.graphics.drawable.Drawable
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.PulseRpcApplication
import com.example.data.local.ActivityLogEntity
import com.example.data.local.AppRuleEntity
import com.example.data.local.PresencePresetEntity
import com.example.data.local.UserPreferences
import com.example.data.model.BroadcastMode
import com.example.data.model.GatewayState
import com.example.data.model.GatewayStatus
import com.example.data.model.InstalledAppInfo
import com.example.data.model.MediaTrackInfo
import com.example.data.model.PermissionStatus
import com.example.data.model.RichPresencePayload
import com.example.data.repository.PresenceRepository
import com.example.service.DetectedForegroundApp
import com.example.service.PresenceForegroundService
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MainUiState(
    val preferences: UserPreferences = UserPreferences(),
    val gatewayState: GatewayState = GatewayState(),
    val activePresence: RichPresencePayload = RichPresencePayload(),
    val permissions: PermissionStatus = PermissionStatus(),
    val detectedApp: DetectedForegroundApp? = null,
    val currentMedia: MediaTrackInfo? = null,
    val installedApps: List<InstalledAppInfo> = emptyList(),
    val appRules: Map<String, AppRuleEntity> = emptyMap(),
    val presets: List<PresencePresetEntity> = emptyList(),
    val recentLogs: List<ActivityLogEntity> = emptyList(),
    val manualPreviewApp: InstalledAppInfo? = null
) {
    fun resolveAppIcon(packageName: String?): Drawable? {
        if (packageName == null) return null
        return installedApps.firstOrNull { it.packageName == packageName }?.icon
    }
}

class MainViewModel(
    application: Application,
    private val repository: PresenceRepository
) : AndroidViewModel(application) {

    private val _uiMessages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val uiMessages: SharedFlow<String> = _uiMessages.asSharedFlow()

    private val coreFlow = combine(
        repository.preferencesFlow,
        repository.gatewayStateFlow,
        repository.activePresence,
        repository.permissions,
        repository.detectedApp
    ) { prefs, gw, presence, perms, detected ->
        CoreSlice(prefs, gw, presence, perms, detected)
    }

    private val dataFlow = combine(
        repository.currentMediaFlow,
        repository.installedApps,
        repository.appRulesFlow,
        repository.presetsFlow,
        repository.recentLogsFlow
    ) { media, apps, rules, presets, logs ->
        DataSlice(media, apps, rules.associateBy { it.packageName }, presets, logs)
    }

    val uiState: StateFlow<MainUiState> = combine(
        coreFlow,
        dataFlow,
        repository.manualPreviewApp
    ) { core, data, previewApp ->
        val mergedUser = core.gw.user ?: core.prefs.cachedUser
        MainUiState(
            preferences = core.prefs,
            gatewayState = core.gw.copy(user = mergedUser),
            activePresence = core.presence,
            permissions = core.perms,
            detectedApp = core.detected,
            currentMedia = data.media,
            installedApps = data.apps,
            appRules = data.rules,
            presets = data.presets,
            recentLogs = data.logs,
            manualPreviewApp = previewApp
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MainUiState()
    )

    init {
        viewModelScope.launch {
            repository.gatewayStateFlow.collect { gw ->
                if (gw.status == GatewayStatus.CONNECTED && gw.user != null) {
                    repository.preferencesManager.saveCachedUser(gw.user)
                }
            }
        }
        viewModelScope.launch {
            repository.pollAndSyncPresence(logChanges = false)
        }
    }

    fun refreshOnResume() {
        viewModelScope.launch {
            repository.refreshPermissions()
            repository.pollAndSyncPresence(logChanges = false)
        }
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            repository.refreshInstalledApps()
            _uiMessages.tryEmit("App list refreshed")
        }
    }

    fun toggleBroadcast(enable: Boolean) {
        viewModelScope.launch {
            repository.preferencesManager.setBroadcastingActive(enable)
            if (enable) {
                PresenceForegroundService.start(getApplication())
                repository.pollAndSyncPresence(logChanges = true)
                _uiMessages.tryEmit("Live Rich Presence broadcast started")
            } else {
                PresenceForegroundService.stop(getApplication())
                repository.gatewayClient.sendPresence(null)
                _uiMessages.tryEmit("Rich Presence broadcast paused")
            }
        }
    }

    fun setBroadcastMode(mode: BroadcastMode) {
        viewModelScope.launch {
            repository.setBroadcastMode(mode)
        }
    }

    fun selectPreviewApp(app: InstalledAppInfo?) {
        viewModelScope.launch {
            if (app != null) {
                repository.setBroadcastMode(BroadcastMode.AUTO_APP)
            }
            repository.selectPreviewApp(app)
            if (app != null) {
                _uiMessages.tryEmit("Previewing ${app.appName}")
            }
        }
    }

    fun toggleAppEnabled(packageName: String, appName: String, enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleAppEnabled(packageName, appName, enabled)
        }
    }

    fun saveAppRule(rule: AppRuleEntity) {
        viewModelScope.launch {
            repository.saveAppRule(rule)
            _uiMessages.tryEmit("Saved custom presence for ${rule.appName}")
        }
    }

    fun setBatchAppEnabled(gamesOnly: Boolean?, enabled: Boolean) {
        viewModelScope.launch {
            repository.setBatchAppEnabled(gamesOnly, enabled)
            val msg = when {
                gamesOnly == true -> "Enabled games only"
                enabled -> "All apps enabled"
                else -> "All apps disabled"
            }
            _uiMessages.tryEmit(msg)
        }
    }

    fun saveCustomRpc(payload: RichPresencePayload, broadcastNow: Boolean) {
        viewModelScope.launch {
            repository.saveCustomRpc(payload, broadcastNow)
            if (broadcastNow) {
                if (!uiState.value.preferences.isBroadcastingActive) {
                    repository.preferencesManager.setBroadcastingActive(true)
                    PresenceForegroundService.start(getApplication())
                }
                _uiMessages.tryEmit("Custom Rich Presence is now live")
            } else {
                _uiMessages.tryEmit("Custom RPC draft saved")
            }
        }
    }

    fun savePreset(preset: PresencePresetEntity) {
        viewModelScope.launch {
            repository.savePreset(preset)
            _uiMessages.tryEmit("Saved preset \"${preset.presetName}\"")
        }
    }

    fun deletePreset(id: Long) {
        viewModelScope.launch {
            repository.deletePreset(id)
            _uiMessages.tryEmit("Preset deleted")
        }
    }

    fun applyPreset(preset: PresencePresetEntity, broadcastNow: Boolean) {
        viewModelScope.launch {
            repository.applyPreset(preset, broadcastNow)
            if (broadcastNow && !uiState.value.preferences.isBroadcastingActive) {
                repository.preferencesManager.setBroadcastingActive(true)
                PresenceForegroundService.start(getApplication())
            }
            _uiMessages.tryEmit("Loaded preset \"${preset.presetName}\"")
        }
    }

    fun connectDiscord(token: String) {
        viewModelScope.launch {
            repository.connectDiscord(token)
        }
    }

    fun disconnectDiscord() {
        viewModelScope.launch {
            repository.disconnectDiscord()
            _uiMessages.tryEmit("Disconnected from Discord Gateway")
        }
    }

    fun setPollingIntervalSec(seconds: Int) {
        viewModelScope.launch {
            repository.preferencesManager.setPollingIntervalSec(seconds)
        }
    }

    fun setShowElapsedTimer(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferencesManager.setShowElapsedTimer(enabled)
            repository.pollAndSyncPresence(logChanges = false)
        }
    }

    fun setIgnoreSelfApp(ignore: Boolean) {
        viewModelScope.launch {
            repository.preferencesManager.setIgnoreSelfApp(ignore)
            repository.pollAndSyncPresence(logChanges = false)
        }
    }

    fun setAutoReconnect(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferencesManager.setAutoReconnect(enabled)
            repository.gatewayClient.updateAutoReconnect(enabled)
        }
    }

    fun setKeepPresenceOnLeave(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferencesManager.setKeepPresenceOnLeave(enabled)
            repository.pollAndSyncPresence(logChanges = false)
            _uiMessages.tryEmit(
                if (enabled) "Keep presence after leaving enabled" else "Immediate clear on leave enabled"
            )
        }
    }

    fun setLeaveDelaySeconds(seconds: Int) {
        viewModelScope.launch {
            val clamped = seconds.coerceIn(1, 3600)
            repository.preferencesManager.setLeaveDelaySeconds(clamped)
            repository.pollAndSyncPresence(logChanges = false)
            _uiMessages.tryEmit("Leave delay set to ${clamped}s")
        }
    }

    fun setCustomElapsed(enabled: Boolean, minutes: Int, seconds: Int) {
        viewModelScope.launch {
            val clampedMin = minutes.coerceIn(0, 1440)
            val clampedSec = seconds.coerceIn(0, 59)
            repository.preferencesManager.setCustomElapsed(enabled, clampedMin, clampedSec)
            repository.pollAndSyncPresence(logChanges = false)
            _uiMessages.tryEmit(
                if (enabled) {
                    "Elapsed timer set to ${clampedMin}m ${clampedSec}s"
                } else {
                    "Custom elapsed offset turned off"
                }
            )
        }
    }

    fun setDefaultApplicationId(appId: String) {
        viewModelScope.launch {
            repository.preferencesManager.setDefaultApplicationId(appId)
            _uiMessages.tryEmit("Default Application ID updated")
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
            _uiMessages.tryEmit("Activity logs cleared")
        }
    }

    private data class CoreSlice(
        val prefs: UserPreferences,
        val gw: GatewayState,
        val presence: RichPresencePayload,
        val perms: PermissionStatus,
        val detected: DetectedForegroundApp?
    )

    private data class DataSlice(
        val media: MediaTrackInfo?,
        val apps: List<InstalledAppInfo>,
        val rules: Map<String, AppRuleEntity>,
        val presets: List<PresencePresetEntity>,
        val logs: List<ActivityLogEntity>
    )

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as PulseRpcApplication
                MainViewModel(app, app.container.presenceRepository)
            }
        }
    }
}
