package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.PresencePresetEntity
import com.example.data.model.ActivityType
import com.example.data.model.RichPresencePayload
import com.example.ui.MainUiState
import com.example.ui.components.DiscordPresenceCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.Blurple

@Composable
fun StudioScreen(
    uiState: MainUiState,
    onApplyCustomRpc: (RichPresencePayload, Boolean) -> Unit,
    onSavePreset: (PresencePresetEntity) -> Unit,
    onDeletePreset: (Long) -> Unit,
    onApplyPreset: (PresencePresetEntity, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val prefs = uiState.preferences

    var activityName by remember { mutableStateOf(prefs.customName) }
    var details by remember { mutableStateOf(prefs.customDetails) }
    var state by remember { mutableStateOf(prefs.customState) }
    var selectedType by remember { mutableStateOf(ActivityType.fromCode(prefs.customTypeCode)) }
    var appId by remember { mutableStateOf(prefs.customAppId) }
    var largeImageUrl by remember { mutableStateOf(prefs.customLargeImageUrl) }
    var largeImageText by remember { mutableStateOf(prefs.customLargeImageText) }
    var smallImageUrl by remember { mutableStateOf(prefs.customSmallImageUrl) }
    var smallImageText by remember { mutableStateOf(prefs.customSmallImageText) }
    var button1Label by remember { mutableStateOf(prefs.customButton1Label) }
    var button1Url by remember { mutableStateOf(prefs.customButton1Url) }
    var button2Label by remember { mutableStateOf(prefs.customButton2Label) }
    var button2Url by remember { mutableStateOf(prefs.customButton2Url) }
    var showElapsed by remember { mutableStateOf(prefs.customShowElapsed) }

    var showSaveDialog by remember { mutableStateOf(false) }
    var presetTitleInput by remember { mutableStateOf("") }

    // Sync when a preset is loaded into preferences
    LaunchedEffect(
        prefs.customName,
        prefs.customDetails,
        prefs.customState,
        prefs.customTypeCode,
        prefs.customAppId
    ) {
        activityName = prefs.customName
        details = prefs.customDetails
        state = prefs.customState
        selectedType = ActivityType.fromCode(prefs.customTypeCode)
        appId = prefs.customAppId
        largeImageUrl = prefs.customLargeImageUrl
        largeImageText = prefs.customLargeImageText
        smallImageUrl = prefs.customSmallImageUrl
        smallImageText = prefs.customSmallImageText
        button1Label = prefs.customButton1Label
        button1Url = prefs.customButton1Url
        button2Label = prefs.customButton2Label
        button2Url = prefs.customButton2Url
        showElapsed = prefs.customShowElapsed
    }

    val previewOffsetMs = if (prefs.customElapsedEnabled) prefs.customElapsedOffsetMs else 125_000L
    val draftPayload = RichPresencePayload(
        applicationId = appId.ifBlank { RichPresencePayload.DEFAULT_DISCORD_APP_ID },
        name = activityName.ifBlank { "PulseRPC" },
        details = details,
        state = state,
        activityType = selectedType,
        largeImageUrl = largeImageUrl,
        largeImageText = largeImageText,
        smallImageUrl = smallImageUrl,
        smallImageText = smallImageText,
        startTimestampMs = if (showElapsed) System.currentTimeMillis() - previewOffsetMs else null,
        button1Label = button1Label,
        button1Url = button1Url,
        button2Label = button2Label,
        button2Url = button2Url,
        sourceLabel = "Studio Live Preview"
    )

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column {
                    Text(
                        text = "RPC Studio",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Craft a custom Discord Rich Presence & save presets",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Live Mini Preview
            item {
                DiscordPresenceCard(
                    payload = draftPayload,
                    user = uiState.gatewayState.user,
                    gatewayStatus = uiState.gatewayState.status,
                    isBroadcasting = prefs.isBroadcastingActive,
                    appIconDrawable = null,
                    compact = true,
                    modifier = Modifier.testTag("studio_preview_card")
                )
            }

            // Saved Presets Carousel
            if (uiState.presets.isNotEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionHeader(
                            title = "Saved Presets",
                            subtitle = "Tap any preset to load & broadcast"
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(uiState.presets, key = { it.id }) { preset ->
                                PresetCard(
                                    preset = preset,
                                    onApply = { onApplyPreset(preset, true) },
                                    onDelete = { onDeletePreset(preset.id) }
                                )
                            }
                        }
                    }
                }
            }

            // Activity Type Selector
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Activity Type",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ActivityType.entries) { type ->
                            FilterChip(
                                selected = selectedType == type,
                                onClick = { selectedType = type },
                                label = { Text(type.prefixLabel) },
                                modifier = Modifier.testTag("studio_type_${type.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            // Core Text Fields
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Presence Details",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )

                        OutlinedTextField(
                            value = activityName,
                            onValueChange = { activityName = it },
                            label = { Text("Activity Name") },
                            placeholder = { Text("e.g., Valorant Mobile") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("studio_name_input")
                        )

                        OutlinedTextField(
                            value = details,
                            onValueChange = { details = it },
                            label = { Text("Details (Line 1)") },
                            placeholder = { Text("e.g., Competitive • Ascendant II") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("studio_details_input")
                        )

                        OutlinedTextField(
                            value = state,
                            onValueChange = { state = it },
                            label = { Text("State (Line 2)") },
                            placeholder = { Text("e.g., In Party (2 of 5)") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("studio_state_input")
                        )

                        OutlinedTextField(
                            value = appId,
                            onValueChange = { appId = it },
                            label = { Text("Discord Application ID") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Elapsed Timer", style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    "Show live 00:00 elapsed counter",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = showElapsed,
                                onCheckedChange = { showElapsed = it },
                                modifier = Modifier.testTag("studio_elapsed_switch")
                            )
                        }
                    }
                }
            }

            // Artwork & Buttons Card
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Artwork & Interactive Buttons",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )

                        OutlinedTextField(
                            value = largeImageUrl,
                            onValueChange = { largeImageUrl = it },
                            label = { Text("Large Image URL or Asset Key") },
                            placeholder = { Text("https://... or discord_asset_key") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = largeImageText,
                            onValueChange = { largeImageText = it },
                            label = { Text("Large Image Tooltip") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = smallImageUrl,
                            onValueChange = { smallImageUrl = it },
                            label = { Text("Small Badge Image URL or Key") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = button1Label,
                                onValueChange = { button1Label = it },
                                label = { Text("Button 1 Label") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = button1Url,
                                onValueChange = { button1Url = it },
                                label = { Text("Button 1 URL") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = button2Label,
                                onValueChange = { button2Label = it },
                                label = { Text("Button 2 Label") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = button2Url,
                                onValueChange = { button2Url = it },
                                label = { Text("Button 2 URL") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Action Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            presetTitleInput = activityName.ifBlank { "My Custom RPC" }
                            showSaveDialog = true
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("studio_save_preset_button"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Rounded.BookmarkAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Preset")
                    }

                    Button(
                        onClick = {
                            val activeOffsetMs = if (prefs.customElapsedEnabled) prefs.customElapsedOffsetMs else 0L
                            onApplyCustomRpc(
                                draftPayload.copy(
                                    startTimestampMs = if (showElapsed) System.currentTimeMillis() - activeOffsetMs else null
                                ),
                                true
                            )
                        },
                        modifier = Modifier
                            .weight(1.3f)
                            .height(52.dp)
                            .testTag("studio_broadcast_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Blurple,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(Icons.Rounded.RocketLaunch, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Go Live")
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save RPC Preset") },
            text = {
                OutlinedTextField(
                    value = presetTitleInput,
                    onValueChange = { presetTitleInput = it },
                    label = { Text("Preset Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("preset_name_dialog_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSavePreset(
                            PresencePresetEntity(
                                presetName = presetTitleInput.trim().ifBlank { "Custom Preset" },
                                applicationId = appId.trim().ifBlank { RichPresencePayload.DEFAULT_DISCORD_APP_ID },
                                activityName = activityName.trim().ifBlank { "PulseRPC" },
                                details = details.trim(),
                                state = state.trim(),
                                activityTypeCode = selectedType.code,
                                largeImageUrl = largeImageUrl.trim(),
                                largeImageText = largeImageText.trim(),
                                smallImageUrl = smallImageUrl.trim(),
                                smallImageText = smallImageText.trim(),
                                button1Label = button1Label.trim(),
                                button1Url = button1Url.trim(),
                                button2Label = button2Label.trim(),
                                button2Url = button2Url.trim(),
                                showElapsedTime = showElapsed
                            )
                        )
                        showSaveDialog = false
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun PresetCard(
    preset: PresencePresetEntity,
    onApply: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        onClick = onApply,
        modifier = Modifier
            .width(196.dp)
            .testTag("preset_card_${preset.id}"),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = preset.presetName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = "Delete preset ${preset.presetName}",
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Text(
                text = "${ActivityType.fromCode(preset.activityTypeCode).prefixLabel} ${preset.activityName}",
                style = MaterialTheme.typography.bodySmall,
                color = Blurple,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (preset.details.isNotBlank()) {
                Text(
                    text = preset.details,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
