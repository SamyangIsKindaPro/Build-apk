package com.example.ui.components

import android.graphics.drawable.Drawable
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Games
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.LiveTv
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.ActivityType
import com.example.data.model.DiscordUser
import com.example.data.model.GatewayStatus
import com.example.data.model.RichPresencePayload
import com.example.ui.theme.Blurple
import com.example.ui.theme.IdleAmber
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.OnlineGreenBright
import kotlinx.coroutines.delay

@Composable
fun DiscordPresenceCard(
    payload: RichPresencePayload,
    user: DiscordUser?,
    gatewayStatus: GatewayStatus,
    isBroadcasting: Boolean,
    appIconDrawable: Drawable?,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    val uriHandler = LocalUriHandler.current
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(payload.startTimestampMs, isBroadcasting) {
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val isLiveOnDiscord = gatewayStatus == GatewayStatus.CONNECTED && isBroadcasting && !payload.isStandby

    val statusColor by animateColorAsState(
        targetValue = when {
            payload.graceRemainingSeconds != null -> IdleAmber
            isLiveOnDiscord -> OnlineGreenBright
            isBroadcasting && !payload.isStandby -> NeonCyan
            gatewayStatus == GatewayStatus.CONNECTING || gatewayStatus == GatewayStatus.RECONNECTING -> IdleAmber
            else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f)
        },
        label = "status_color"
    )

    val cardBorderColor = if (isLiveOnDiscord) {
        OnlineGreenBright.copy(alpha = 0.55f)
    } else if (isBroadcasting && !payload.isStandby) {
        Blurple.copy(alpha = 0.55f)
    } else {
        MaterialTheme.colorScheme.outline.copy(alpha = 0.7f)
    }

    val localIconPainter = remember(appIconDrawable) {
        appIconDrawable?.let { drawable ->
            runCatching { BitmapPainter(drawable.toBitmap(128, 128).asImageBitmap()) }.getOrNull()
        }
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.2.dp, cardBorderColor),
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (compact) 52.dp else 74.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_presence_hero),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.15f),
                                    MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.92f)
                                )
                            )
                        )
                )

                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp),
                    shape = RoundedCornerShape(50),
                    color = Color.Black.copy(alpha = 0.6f),
                    border = BorderStroke(1.dp, statusColor.copy(alpha = 0.55f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                        Text(
                            text = when {
                                payload.isStandby -> "HIDDEN ON DISCORD"
                                payload.graceRemainingSeconds != null -> "GRACE • ${payload.graceRemainingSeconds}S"
                                isLiveOnDiscord -> "DISCORD LIVE"
                                isBroadcasting -> "MOBILE LIVE"
                                else -> "PREVIEW"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(modifier = Modifier.size(if (compact) 42.dp else 48.dp)) {
                        if (!user?.avatarUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = user?.avatarUrl,
                                contentDescription = "Discord profile avatar",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .border(2.dp, MaterialTheme.colorScheme.surfaceContainer, CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Blurple, NeonCyan.copy(alpha = 0.85f))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Person,
                                    contentDescription = "Default profile avatar",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .align(Alignment.BottomEnd)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceContainer)
                                .padding(2.dp)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = user?.displayName ?: "Mobile Rich Presence",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (user != null && user.username.isNotBlank()) {
                                "@${user.username} • ${payload.sourceLabel}"
                            } else {
                                payload.sourceLabel
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = if (payload.isStandby) {
                                    Icons.Rounded.VisibilityOff
                                } else {
                                    activityIcon(payload.activityType)
                                },
                                contentDescription = null,
                                tint = if (payload.isStandby) MaterialTheme.colorScheme.onSurfaceVariant else Blurple,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = if (payload.isStandby) "NOT DISPLAYING ON PROFILE" else payload.activityType.badgeTitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(modifier = Modifier.size(if (compact) 68.dp else 78.dp)) {
                                val fallbackPainter = localIconPainter ?: painterResource(id = R.drawable.img_default_rpc_art)

                                Surface(
                                    modifier = Modifier.fillMaxSize(),
                                    shape = RoundedCornerShape(16.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    when {
                                        localIconPainter != null && !payload.largeImageUrl.startsWith("http") -> {
                                            Image(
                                                painter = localIconPainter,
                                                contentDescription = payload.name,
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(8.dp),
                                                contentScale = ContentScale.Fit
                                            )
                                        }
                                        payload.largeImageUrl.startsWith("http") -> {
                                            AsyncImage(
                                                model = payload.largeImageUrl,
                                                contentDescription = payload.largeImageText.ifBlank { payload.name },
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop,
                                                error = fallbackPainter,
                                                placeholder = fallbackPainter
                                            )
                                        }
                                        else -> {
                                            Image(
                                                painter = painterResource(id = R.drawable.img_default_rpc_art),
                                                contentDescription = payload.name,
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                    }
                                }

                                Surface(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .align(Alignment.BottomEnd),
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.surfaceContainer,
                                    border = BorderStroke(2.dp, MaterialTheme.colorScheme.surfaceContainerHigh)
                                ) {
                                    if (payload.smallImageUrl.startsWith("http")) {
                                        AsyncImage(
                                            model = payload.smallImageUrl,
                                            contentDescription = payload.smallImageText,
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .clip(CircleShape),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(if (payload.isStandby) MaterialTheme.colorScheme.outline else Blurple),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Sensors,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(13.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Text(
                                    text = payload.name.ifBlank { "PulseRPC" },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (payload.details.isNotBlank()) {
                                    Text(
                                        text = payload.details,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.88f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                if (payload.state.isNotBlank()) {
                                    Text(
                                        text = payload.state,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                if (payload.startTimestampMs != null && !payload.isStandby) {
                                    val elapsedSec = ((nowMs - payload.startTimestampMs) / 1000L).coerceAtLeast(0L)
                                    Text(
                                        text = "${formatDuration(elapsedSec)} elapsed",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = JetBrainsMonoFamily
                                        ),
                                        color = OnlineGreenBright
                                    )
                                }
                            }
                        }

                        val hasBtn1 = payload.button1Label.isNotBlank() && payload.button1Url.isNotBlank()
                        val hasBtn2 = payload.button2Label.isNotBlank() && payload.button2Url.isNotBlank()
                        if ((hasBtn1 || hasBtn2) && !payload.isStandby) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (hasBtn1) {
                                    RpcActionButton(
                                        label = payload.button1Label,
                                        onClick = {
                                            runCatching { uriHandler.openUri(payload.button1Url) }
                                        }
                                    )
                                }
                                if (hasBtn2) {
                                    RpcActionButton(
                                        label = payload.button2Label,
                                        onClick = {
                                            runCatching { uriHandler.openUri(payload.button2Url) }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RpcActionButton(
    label: String,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
            contentColor = MaterialTheme.colorScheme.onSurface
        )
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.width(6.dp))
        Icon(
            imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
            contentDescription = null,
            modifier = Modifier.size(14.dp)
        )
    }
}

private fun activityIcon(type: ActivityType) = when (type) {
    ActivityType.PLAYING -> Icons.Rounded.SportsEsports
    ActivityType.STREAMING -> Icons.Rounded.Videocam
    ActivityType.LISTENING -> Icons.Rounded.Headphones
    ActivityType.WATCHING -> Icons.Rounded.LiveTv
    ActivityType.COMPETING -> Icons.Rounded.Games
}

fun formatDuration(totalSeconds: Long): String {
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0) {
        String.format("%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}
